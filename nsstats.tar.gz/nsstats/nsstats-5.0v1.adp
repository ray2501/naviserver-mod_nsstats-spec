<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><%=$::title%></title>
  <link rel="icon" type="image/svg+xml" href="favicon.svg">
  <!-- Include W3.CSS -->
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <style>
    /* Custom Header: Overall container is blue */
    header.custom-header {
      background: #004080 !important;
      color: #fff;
      padding: 20px;
    }
    /* h1 in header: blue background with white text */
    header.custom-header h1 {
      background: #004080 !important;
      color: #fff !important;
      padding: 10px;
      margin: 0;
      display: inline-block;
    }
    /* Right side of header: Hostname and date/time */
    header.custom-header .header-right {
      float: right;
      text-align: right;
    }
    header.custom-header .header-right p {
      margin: 0;
      line-height: 1.2;
    }
    /* Custom Menubar: Force blue background */
    .menu-bar.custom-menubar {
      background: #004080 !important;
      color: #fff;
    }
    .menu-bar.custom-menubar a {
      color: #fff;
      text-decoration: none;
    }
    /* Override dropdown links inside custom menubar for contrast */
    .menu-bar.custom-menubar .w3-dropdown-hover .w3-dropdown-content a {
      color: #004080 !important;
      padding: 4px 10px;
    }
    /* Override dropdown content width so it fits text */
    .menu-bar.custom-menubar .w3-dropdown-hover .w3-dropdown-content {
      width: 250px;
    }
    /* Active menu item styling */
    .menu-bar.custom-menubar a.active {
      background: #0056b3 !important;
    }
    /* Dropdown buttons with marker styling */
    .dropdown-btn {
      background: #004080 !important;
      color: #fff !important;
      border: none;
      padding: 14px 20px;
      display: inline-flex;
      align-items: center;
    }
    .dropdown-btn:hover {
      background: #0056b3 !important;
    }
    .dropdown-marker {
      margin-left: 4px;
      font-size: 0.8em;
      opacity: 0.8;
    }
    /* Regular menu buttons: Force inline-flex display for vertical alignment */
    .menu-bar.custom-menubar .w3-bar-item.w3-button {
      display: inline-flex;
      align-items: center;
      padding: 14px 20px;
    }
    /* Raw toggle styling */
    .no-break {
      white-space: nowrap;
      display: inline-flex;
      align-items: center;
    }
    .raw-label {
      color: #fff;
      font-weight: normal;
    }
    .raw-value {
      color: #ffc107;
      font-weight: bold;
      text-decoration: none;
    }
    .raw-value:hover {
      text-decoration: underline;
    }
    /* Breadcrumbs styling */
    .breadcrumbs {
      padding: 8px 16px;
      background-color: #f1f1f1;
      font-size: 0.9em;
      color: #666;
    }
    .breadcrumbs a {
      color: #004080;
      text-decoration: none;
    }
    .breadcrumbs a:hover {
      text-decoration: underline;
}

    /* Main container using Flexbox */
    .main-container {
      display: flex;
      align-items: flex-start;
      /*padding: 20px;*/
    }

    /* Sidebar styles */
    .sidebar {
      background: #eeeeee;
      padding: 2px 12px;
      width: 300px;
      box-sizing: border-box;
      position: sticky;
      top: 0;
      height: 100vh;
      overflow-y: auto;
      border-right: 1px solid #ccc;
    }
    .sidebar ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }
    .sidebar li {
      margin-bottom: 3px;
    }
    .sidebar a {
      text-decoration: none;
      color: #004080;
      font-size: 13px;
      font-weight: bold;
    }
    /* Main content styles */
    .content {
      flex: 1;
      padding: 0px 20px;
      overflow-y: auto;
    }
    .content h2 {
      color: #004080;
      /*border-bottom: 2px solid #ccc;*/
      padding-bottom: 5px;
      /*margin-top: 40px;*/
    }
    /* h2 elements: left aligned */
    h2 {
      font-size: 1.8rem;
      text-align: left;
      margin: 1rem 0 0.5rem 0;
      padding-bottom: 0.25rem;
      /*border-bottom: 2px solid #ccc;*/
      color: #004080;
    }
    /* Table Styling */
    .w3-table.w3-hoverable {
      background-color: transparent;
      border-collapse: collapse;
      width: 100%;
    }
    .w3-table.w3-hoverable th,
    .w3-table.w3-hoverable td {
      background: #fff;
      padding: 8px;
      text-align: left;
      border: 1px solid #ccc;
      font-size: 0.9rem;
    }
    /* Table Headers: Dark gray background with white text */
    .w3-table.w3-hoverable th {
      background: #999 !important;
      color: #fff !important;
    }
    /* Force key column to be grey */
    .coltitle {
      font-weight: bold;
    }
    /* data-table with dark greyish header and first column (keys) darker than values */
    .data-table {
      width: 100%;
      border-collapse: collapse;
      margin-left: 20px;

    }
    .data-table th:first-child,
    .data-table td:first-child {
       width: 250px;
    }
    .data-table th, .data-table td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: left;
    }
    .data-table th {
      background: #999;
      color: #fff;
    }
    tr.sortable td.selected   { background: #666666; color: #ffffff; }
    tr.sortable td.unselected { background: #999999; color: #ffffff; }
    tr.data td.selected       { background: #ececec; }
    tr.data td.unselected     { background: #ffffff; }



/* For nested table in process page */
table.data td td.subtitle {text-align: right; white-space: nowrap; font-style: italic; background-color: #f5f5f5;}
table.data td table td {font-size:smaller !important; padding: 2px !important; border-width: 0px !important;}

/* Styling for defaulted/unread/notneed parameters */
td.defaulted {color: #aaa;}
td.unread {color: red;}
td.notneeded {color: orange;}
table.config {font-size: 0.9rem;}

.tip {
   cursor: help;
   color: #777777;
   position: relative;
}
.tip::after {
  content: " ⓘ";
  font-size: 0.9em;
  color: #777;
  margin-left: 4px;
}

.tooltip {
  position: relative;
  /*display: inline-block;*/
  /*border-bottom: 1px dotted black;*/ /* If you want dots under the hoverable text */
}

.tooltip .tooltiptext {
   visibility: hidden;
   width: 200px;
   background-color: #999;
   color: #fff;
   text-align: center;
   padding: 5px 0;
   margin-left: 15px;
   margin-top: -5px;
   border-radius: 6px;
   position: absolute;
   z-index: 1;
}
.tooltip.unread .tooltiptext { background-color: #900;}
.tooltip.unread .tooltiptext::after {border-color: transparent #900 transparent transparent;}
.tooltip.defaulted .tooltiptext { background-color: #aaa;}
.tooltip.defaulted .tooltiptext::after { border-color: transparent #aaa transparent transparent;}
.tooltip.notneeded .tooltiptext { background-color: orange;}
.tooltip.notneeded .tooltiptext::after { border-color: transparent orange transparent transparent;}

.tooltip:hover .tooltiptext {visibility: visible;}
.tooltip .tooltiptext::after {
   content: " ";
   position: absolute;
   top: 50%;
   right: 100%; /* To the left of the tooltip */
   margin-top: -5px;
   border-width: 5px;
   border-style: solid;
   border-color: transparent #999 transparent transparent;
}


  </style>
  <%= $::extraHeadEntries %>
</head>

<body>
<%
    set linkLines {}
    set level 0
    foreach {name label} $::navLinks {
        if {$name eq "process"} continue
        set dropdown [expr {[info procs _ns_stats.$name] eq ""}]
        set postincr 0
        
        if {$dropdown} {
            set item [subst [ns_trim -delimiter | {
                |<div class="w3-dropdown-hover">
                | <button class="w3-button dropdown-btn">$label<span class="dropdown-marker">▼</span></button>
                | <div class="w3-dropdown-content w3-bar-block w3-card-4">}]]
            set postincr 1
        } else {
            set item \
                "<a href='?@page=$name$::rawparam' class='w3-bar-item w3-button w3-mobile'>$label</a>"
        }
        if {$level == 1 && ![string match *.* $name]} {
            #
            # End pulldown before outputting next item.
            #
            lappend linkLines </div></div>       
            incr level -1
        }
        lappend linkLines "[string repeat {  } $level]$item"
        incr level $postincr
    }        
    lappend linkLines \
            [subst [ns_trim -delimiter | {
              |<div class='w3-right w3-bar-item no-break'>
              | <span class="raw-toggle">
              |   <span class="raw-label">Raw:</span>&nbsp;
              |   <a class='current w3-text-amber' href='$::rawUrl'>$::rawLabel</a>
              | </span>
              |</div>}]]
%>
              
<!-- Header -->
<header class="w3-container custom-header">
  <h1 class="w3-left">NaviServer Statistics</h1>
  <div class="header-right">
    <p class="w3-small"><strong><%=[ns_info hostname]%></strong></p>
    <p class="w3-small"><%=[_ns_stats.fmtTime [ns_time]]%></p>
  </div>
  <div style="clear: both;"></div>
</header>

<!-- Navigation Bar -->
<div class="w3-bar menu-bar custom-menubar">
<%= [join $linkLines \n] %>
</div>

<!-- Breadcrumbs -->
<div class="w3-container breadcrumbs">
  <a href="/">Home</a> &gt; <a href="<%=[ns_conn url]%>">nsstats</a>  &gt; <%=[dict get $::navLinks $::page]%>
  <!-- <%= $::nav %> -->
</div>

<!-- Main Container -->
<div class="main-container">
  <!-- Sidebar -->
  <%=[expr {[info exists ::sidebar] ? $::sidebar : ""}]%>
  <!-- Main Content -->
    <div class="content"> 
    <h2><%=[dict get $::titles $::page]%></h2>
<%= $html %>
    </div>
</div>

<footer class="w3-container w3-light-grey w3-center">
<%= $::footer %>
</footer>

</body>
</html>

